import PasteEditor from './paste-editor.vue'
export default PasteEditor
