import countTo from './count-to.vue'
export default countTo
